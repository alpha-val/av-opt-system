from fastapi import FastAPI

def create_app() -> FastAPI:
    app = FastAPI(title="Alpha‑Val Optionality API (Minimal)", version="0.0.1")

    @app.get("/health")
    def health():
        return {"status": "ok"}

    return app

app = create_app()
